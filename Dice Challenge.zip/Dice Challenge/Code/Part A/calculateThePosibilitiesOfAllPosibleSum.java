public class calculateThePosibilitiesOfAllPosibleSum {
    public static void main(String[] args) {
        // Number of faces on each die
        int faces = 6;

        // Create a 6x6 matrix to represent the distribution
        int[][] distribution = new int[faces][faces];

        // Calculate and fill the distribution matrix
        for (int i = 0; i < faces; i++) {
            for (int j = 0; j < faces; j++) {
                distribution[i][j] = (i + 1) + (j + 1); // Sum of Die A and Die B
            }
        }

        // Calculate the probability of each sum occurring
        System.out.println("Probability of each possible sum:");
        for (int sum = 2; sum <= 12; sum++) {
            int count = countOccurrences(distribution, sum);
            double probability = (double) count / 36;
            System.out.println("P(Sum = " + sum + ") = " + count + "/36 = " + probability);
        }
    }

    // Method to count the occurrences of a given sum in the distribution matrix
    private static int countOccurrences(int[][] distribution, int sum) {
        int count = 0;
        for (int i = 0; i < distribution.length; i++) {
            for (int j = 0; j < distribution[i].length; j++) {
                if (distribution[i][j] == sum) {
                    count++;
                }
            }
        }
        return count;
    }
}
