public class distributionOfAllPosibleCombination {

        public static void main(String[] args) {
            int numFaces = 6;
            int[][] distribution = new int[numFaces][numFaces];

            // Calculate distribution
            for (int i = 0; i < numFaces; i++) {
                for (int j = 0; j < numFaces; j++) {
                    int sum = (i + 1) + (j + 1); // Sum of Die A and Die B
                    distribution[i][j] = sum;
                }
            }

            // Display distribution
            System.out.println("Distribution of all possible combinations:");
            for (int i = 0; i < numFaces; i++) {
                for (int j = 0; j < numFaces; j++) {
                    System.out.print(distribution[i][j] + "\t");
                }
                System.out.println();
            }
        }
    }


