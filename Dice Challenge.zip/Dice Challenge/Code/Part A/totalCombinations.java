public class totalCombinations {
    public static void main(String[] args) {
        int numFaces = 6;
        int totalCombinations = numFaces * numFaces;
        System.out.println("Total combinations: " + totalCombinations);
    }
}
