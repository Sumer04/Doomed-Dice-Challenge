import java.util.*;

public class partB {
    public static void main(String[] args) {
        int[] originalDieA = { 1, 2, 3, 4, 5, 6 };
        int[] originalDieB = Arrays.copyOf(originalDieA, originalDieA.length);

        int[] newDieA = undoomDie(originalDieA, originalDieB);
        int[] newDieB = Arrays.copyOf(originalDieA, originalDieA.length);

        System.out.println("New Die A: " + Arrays.toString(newDieA));
        System.out.println("New Die B: " + Arrays.toString(newDieB));
    }

    public static int[] undoomDie(int[] dieA, int[] dieB) {
        // Calculate the current distribution of sums
        Map<Integer, Integer> sumDistribution = new HashMap<>();
        for (int faceA : dieA) {
            for (int faceB : dieB) {
                int sum = faceA + faceB;
                sumDistribution.put(sum, ((Object) sumDistribution).getOrDefault(sum, 0) + 1);
            }
        }

        // Calculate the probabilities of each sum
        Map<Integer, Double> sumProbabilities = new HashMap<>();
        for (int sum : sumDistribution.keySet()) {
            double probability = (double) sumDistribution.get(sum) / (dieA.length * dieB.length);
            sumProbabilities.put(sum, probability);
        }

        // Sort the sums by their probabilities in descending order
        List<Integer> sortedSums = new ArrayList<>(sumProbabilities.keySet());
        sortedSums.sort((a, b) -> Double.compare(sumProbabilities.get(b), sumProbabilities.get(a)));

        // Generate new Die A according to the probabilities
        int[] newDieA = new int[dieA.length];
        Arrays.fill(newDieA, -1); // Initialize newDieA with placeholder values
        for (int sum : sortedSums) {
            int faceA = sum - 1; // Subtract 1 to get the index of Die A
            if (newDieA[faceA] == -1 && dieA[faceA] < 5) {
                newDieA[faceA] = sum - dieB[0]; // Calculate the corresponding face value of Die A
            }
        }

        // Fill remaining faces of Die A with any available values
        for (int i = 0; i < newDieA.length; i++) {
            if (newDieA[i] == -1) {
                for (int j = 0; j < dieA.length; j++) {
                    if (dieA[j] < 5) {
                        newDieA[i] = dieA[j];
                        break;
                    }
                }
            }
        }

        return newDieA;
    }
}
